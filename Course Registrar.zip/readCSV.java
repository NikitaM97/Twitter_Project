import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by nikitamokhov on 19/02/2017.
 */
public class readCSV{
    readCSV(){};
    public ArrayList<Course> readIn(){
        ArrayList<Course> cs=new ArrayList<>();
        try {

            String csvfile = "MyUniversityCourses (1).csv";
            BufferedReader br = null;
            String line = "";
            String cvsSplitby = ",";
            br = new BufferedReader(new FileReader(csvfile));
            while ((line = br.readLine()) != null) {
                if (line.contains("Course_Id,Maximum_Students")) {
                    continue;
                }
                if (line.contains("Course_Section_Number,Course_Location"))
                    continue;
                else {
                    Course new_course = new Course();
                    String[] data = line.split(cvsSplitby);
                    new_course.setName(data[0]);
                    new_course.setId(data[1]);
                    new_course.setMaxStudents(Integer.parseInt(data[2]));
                    new_course.setRegisteredStudents(Integer.parseInt(data[3]));
                    new_course.setProfessor(data[5]);
                    new_course.setSection(Integer.parseInt(data[6]));
                    new_course.setLocation(data[7]);
                    cs.add(new_course);

                }


            }
            return cs;

        }
        catch(IOException FileNotFoundException){
            System.out.println("Exception occurred");
            return cs;

        }
    }
}
