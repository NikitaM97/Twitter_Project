import java.util.ArrayList;

/**
 * Created by nikitamokhov on 19/02/2017.
 */
//super class user should contain password/username and first name/last name to be inheritted by subclass admin. Also contains a view all method
public class User {
    User(){};
    protected String username;
    protected String password;
    protected String firstName;
    protected String lastName;
    protected String first_time;

}
