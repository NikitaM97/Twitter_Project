import java.util.Scanner;

/**
 * Created by nikitamokhov on 19/02/2017.
 */


//Had major issues with Scanner for the duration of the assignment.
    //sometimes nextLine() would cause whole program to crash hence why the program can sometimes struggle w/ inputs
    //also the reason I put all menus in the application class even though in the original version of my program all menus where within student/admin objects

public class Application_Class {
    public static void main(String[] args) {
        {
            Scanner input1 = new Scanner(System.in);
            //give the user the option of being an admin or student
            System.out.println("Enter 1 if you are an admin, 2 if a student");
            int user = input1.nextInt();
            //whether or not is their first time determines whether deserialization is necessary
            System.out.println("Is this your first time using this program? Enter yes or no (can only input yes if an admin)");
            String newbie = input1.next();
            if (user == 1) {
                //if the user is an admin then display this menu
                System.out.println("Enter your username");
                String username = input1.next();
                System.out.println("Enter passcode");
                String password = input1.next();
                System.out.println("Enter your first name");
                String first_name = input1.next();
                System.out.println("Enter your last name");
                String last_name = input1.next();
                if (username.equals("Admin") && password.equals("Admin001")) {
                    Admin admin = new Admin(username, password, first_name, last_name, newbie);
                    while (true) {
                        //present options of 1) Course Management, 2) Reports, 3) Exits
                        System.out.println("Enter what would you like to do? 1) Course Management" + "\n" + "2) Reports" + "\n" + "3) Exit");
                        int a = input1.nextInt();
                        if (a == 1) {
                            while (true) {
                                System.out.println("1) Create New Course" + "\n" + "2)Delete a Course" + "\n" + "3)Edit a course" + "\n" + "4)Display course information" + "\n" + "5) Register a student" + "\n" + "6)Exit");
                                int b = input1.nextInt();
                                String str = input1.nextLine();
                                if (b == 1) {
                                    System.out.println("Enter the course name");
                                    String name = input1.next();
                                    System.out.println("Enter the course id");
                                    String id = input1.next();
                                    System.out.println("Enter the course instructor's name");
                                    String professor = input1.next();
                                    System.out.println("Enter the maximum number of students");
                                    int max_students = input1.nextInt();
                                    System.out.println("Enter the course section");
                                    int sec = input1.nextInt();
                                    System.out.println("Enter the course location");
                                    String location = input1.next();

                                    admin.create_course(name, id, max_students, 0, null, professor, sec, location);
                                }
                                if (b == 2) {
                                    System.out.println("Enter the course id");
                                    String delete_id = input1.next();
                                    admin.delete_course(delete_id);
                                }
                                if (b == 3)
                                    admin.edit_course();
                                if (b == 4) {
                                    System.out.println("Enter the course id");
                                    String display_id = input1.next();
                                    admin.display_course_info(display_id);
                                }
                                if (b == 5)
                                    admin.register_student();
                                if (b == 6)
                                    break;
                            }
                        }
                        if (a == 2) {
                            while (true) {
                                System.out.println("1)View all courses" + "\n" + "2) View all full courses" + "\n" + "3)Write full course file" + "\n" + "4)View students registered in a course" + "\n" + "5)View courses a student is registered in" + "\n" + "6)Sort" + "\n" + "7)Exit");
                                int c = input1.nextInt();
                                if (c == 1)
                                    admin.viewAll();
                                if (c == 2)
                                    admin.view_full_courses();
                                if (c == 3)
                                    admin.write_full_course_file();
                                if (c == 4) {
                                    System.out.println("Enter the course id");
                                    String view_id = input1.next();
                                    admin.view_registered_students(view_id);
                                }
                                if (c == 5) {
                                    System.out.println("Enter the first name of the student you'd like to see");
                                    String first_Name = input1.next();
                                    System.out.println("Enter the last name of the student you'd like to see");
                                    String last_Name = input1.next();
                                    for (Student s : admin.Allstudents) {
                                        if (s.firstName.equals(first_Name) && s.lastName.equals(last_Name))
                                            admin.view_courses_of_student(s);
                                        else{
                                            System.out.println("No student found");
                                        }
                                    }
                                }
                                if (c == 6)
                                    admin.sort();
                                if (c == 7)
                                    break;
                            }
                        }
                            if (a == 3) {
                                admin.Serialize();
                                break;
                            }
                        }
                    }

                }
                //create the user menu
                if (user == 2) {
                    System.out.println("Enter your username");
                    String username1= input1.next();
                    System.out.println("Enter your password");
                    String password1=input1.next();
                    System.out.println("Enter your first name");
                    String firstname1=input1.next();
                    System.out.println("Enter your last name");
                    String lastname1=input1.next();
                    Student stud=new Student(username1,password1,firstname1,lastname1);
                    while (true) {
                        //display student options menu
                        System.out.println("\n" + "Enter what would you like to do 1) View all courses" + "\n" + "2) View all courses that are not full" + "\n" + "3) Register on a course" + "\n" + "4) Withdraw from a course" + "\n" + "5) View all courses the current student is being registered in" + "\n" + "6) Exit");
                        int a = input1.nextInt();
                        String str = input1.nextLine();
                        if (a == 1)
                            stud.viewAll();
                        if (a == 2)
                            stud.viewNotFull();
                        if (a == 3) {
                            System.out.println("Enter the id of the course you would like to register for.");
                            String name = input1.next();
                            input1.nextLine();
                            System.out.println("Enter the section of the course you would like to register in ");

                            int sec = input1.nextInt();
                            stud.register(name, sec);
                        }
                        if (a == 4) {
                            System.out.println("Enter the id of the course you would like to withdraw from ");
                            String id = input1.next();
                            stud.withdraw(id);
                        }
                        if (a == 5)
                            stud.viewregistered();
                        if (a == 6) {
                            stud.Serialize();
                            break;
                        }
                    }
                }
            }
        }
    }

