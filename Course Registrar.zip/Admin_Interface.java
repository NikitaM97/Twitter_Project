/**
 * Created by nikitamokhov on 19/02/2017.
 */
public interface Admin_Interface {
    public void create_course(String name, String id, int maxStudents, int registeredStudents, Student student,
                              String instructor, int sectionNumber, String location);

    public void delete_course(String courseid);

    public void edit_course();

    public void display_course_info(String id);

    public void register_student();

    public void view_full_courses();

    public void write_full_course_file();

    public void view_registered_students(String id);


    public void view_courses_of_student(Student student);

    public void sort();

}
