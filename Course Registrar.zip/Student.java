import java.io.*;
import java.util.ArrayList;

/**
 * Created by nikitamokhov on 19/02/2017.
 */
//must implement serializable
public class Student extends User implements Student_Interface, java.io.Serializable{
    ArrayList<Student> Allstudents=new ArrayList<>();
    ArrayList<Course> courses=new ArrayList<>();

    Student (String Username,String password,String firstName, String lastName) {
        this.username = Username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        DeSerialize();
        //use first_time to determine whether or not the file needs to deserialize ser files or read in from the csv file

    }
    //create a default constructor to allow for inportation of AllStudents array in application class
    Student(){};
    //create a constructor where the admin can add a student object
    Student(String first_name, String last_name){
        super.firstName=first_name;
        super.lastName=last_name;
        username=first_name+"2017";
        password=last_name+"NYU19";
        Allstudents.add(this);
    }
    public void Serialize(){
        try{
            FileOutputStream fos= new FileOutputStream("Student File");
            ObjectOutputStream oos= new ObjectOutputStream(fos);
            oos.writeObject(Allstudents);
            FileOutputStream fis=new FileOutputStream("Courses File");
            ObjectOutputStream ois=new ObjectOutputStream(fis);
            ois.writeObject(courses);
            oos.close();
            fos.close();
            fis.close();
            ois.close();
        }catch(IOException ioe) {
            ioe.printStackTrace();
        }
    }
    //create a DeSerialize method
    public void DeSerialize(){
        try{
            FileInputStream fis=new FileInputStream("Student File");
            ObjectInputStream ois=new ObjectInputStream(fis);
            Allstudents=(ArrayList) ois.readObject();
            FileInputStream fos=new FileInputStream("Courses File");
            ObjectInputStream oos=new ObjectInputStream(fos);
            courses= (ArrayList) oos.readObject();
            ois.close();
            fis.close();
            fos.close();
            oos.close();
        }
        catch(IOException ioe){
            ioe.printStackTrace();
        }
        catch (ClassNotFoundException c){
            c.printStackTrace();
        }

    }

    //create a view all method
    public void viewAll(){
        //goes through all course object in courses array
        for (Course c:courses){
            System.out.println("\n");
            c.printCourseInfo();
        }
    }
    public void viewNotFull(){
        for (Course c:courses){
            if (c.getRegisteredStudents()!=c.maxStudents){
                c.printCourseInfo();
            }
        }
    }

    //loops through all courses and checks if course id equals the user input and section
    public void register(String id, int section){
        for (Course c:courses){
            if (c.getId().equals(id)&& c.getSection()==section) {
                //checks if registered students is greater than the max allowed and if the student is already registered in the course
                if (c.students.contains(this))
                    System.out.println("You are already registered in this course.");
                if (c.getRegisteredStudents() >= c.maxStudents)
                    System.out.println("Sorry course is already full");
                else {
                    c.addStudent(this);
                }
            }
        }
    }


public void withdraw(String id ){
        //loops through courses and compares course id with the input id. if matches it removes the student object from the arraylist
        for (Course c:courses){
            if (c.getId().equals(id)){
                c.removeStudent(this);
            }
        }
}

public void viewregistered(){
    for (Course c:courses){
        if (c.getStudents().contains(this)){
            c.printCourseInfo();
        }
    }
}
}
