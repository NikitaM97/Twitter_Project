/**
 * Created by nikitamokhov on 19/02/2017.
 */
public interface Student_Interface {

    public void viewNotFull();
    public void register(String id, int section);
    public void withdraw(String id);
    public void viewregistered();
}