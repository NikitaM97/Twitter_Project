import java.util.ArrayList;

/**
 * Created by nikitamokhov on 19/02/2017.
 */
//must implement Serializable
//creates a course class which contains all relevant course information, getters and setters, etc
public class Course implements java.io.Serializable {
    protected String name;
    protected String id;
    protected int maxStudents;
    protected int registeredStudents;
    protected ArrayList<Student> students = new ArrayList<>();
    protected String professor;
    protected int section;
    protected String location;
    //default constructor
    Course(){};
    //constructor which takes in data
    Course(String name, String id, int maxStudents, int registeredStudents, Student students, String professor, int section, String location){
        this.name=name;
        this.id=id;
        this.maxStudents=maxStudents;
        this.registeredStudents=registeredStudents;
        this.students.add(students);
        this.professor=professor;
        this.section=section;
        this.location=location;
    }
    //create all getters
    public String getName(){
        return name;
    }
    public String getId(){return id;}

    public int getMaxStudents(){return maxStudents;}

    public int getRegisteredStudents(){return registeredStudents;}

    public ArrayList<Student> getStudents(){return students;}

    public String getProfessor(){return professor;}

    public int getSection(){return section;}

    public String getLocation(){return location;}

    //create all setters

    public void setName(String name){
        this.name=name;
    }
    public void setId(String id){this.id=id;}

    public void setMaxStudents(int maxStudents){this.maxStudents=maxStudents;}

    public void setRegisteredStudents(int registeredStudents){this.registeredStudents=registeredStudents;}

    public void addStudent(Student student){
        this.students.add(student);
        registeredStudents+=1;
    }
    public void removeStudent(Student student){
        this.students.remove(student);
        registeredStudents-=1;
    }
    public void setProfessor(String professor){this.professor=professor;}

    public void setSection(int Section){this.section=Section;}

    public void setLocation(String location){this.location=location;}

    //create a print course info method
    public void printCourseInfo(){
        System.out.println("Course name: "+this.name+"\n"+"Course id: "+this.id+"\n"+"Number of students registered: "+this.getRegisteredStudents()+"\n"+"Max students allowed: "+this.maxStudents+"\n"+"Professor: "+this.professor);
    }




}