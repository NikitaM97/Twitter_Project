/**
 * Created by nikitamokhov on 19/02/2017.
 */
import java.io.*;
import java.util.*;

public class Admin extends User implements Admin_Interface, java.io.Serializable {
    ArrayList<Student> Allstudents=new ArrayList<>();
    ArrayList<Course> courses=new ArrayList<>();
Admin(String Username,String password,String firstName, String lastName, String first_time) {
    this.username = Username;
    this.password = password;
    this.firstName = firstName;
    this.lastName = lastName;
    this.first_time = first_time;
    if (first_time.equals("yes")) {
        readCSV reader = new readCSV();
        courses=reader.readIn();
    }
    if (first_time.equals("no")){
        DeSerialize();
    }
}
    public void Serialize(){
        try{
            FileOutputStream fos= new FileOutputStream("Student File");
            ObjectOutputStream oos= new ObjectOutputStream(fos);
            oos.writeObject(Allstudents);
            FileOutputStream fis=new FileOutputStream("Courses File");
            ObjectOutputStream ois=new ObjectOutputStream(fis);
            ois.writeObject(courses);
            oos.close();
            fos.close();
            fis.close();
            ois.close();
        }catch(IOException ioe) {
            ioe.printStackTrace();
        }
    }
    //creates a new course object and adds it to user arraylist of courses
    public void create_course(String name, String id, int maxStudents, int registeredStudents, Student student,
                              String instructor, int sectionNumber, String location) {
        Course a=new Course(name,id,maxStudents,registeredStudents,student,instructor,sectionNumber,location);
        courses.add(a);

    }
    public void delete_course(String courseid) {
        //loops through courses and matches the id, and removes the course from the arraylist of coruses
        for (Course c : courses) {
            if (c.getId().equals(courseid)) {
                courses.remove(c);
                break;
            }
        }
    }
    private void DeSerialize(){
        try{
            FileInputStream fis=new FileInputStream("Student File");
            ObjectInputStream ois=new ObjectInputStream(fis);
            Allstudents=(ArrayList) ois.readObject();
            FileInputStream fos=new FileInputStream("Courses File");
            ObjectInputStream oos=new ObjectInputStream(fos);
            courses= (ArrayList) oos.readObject();
            ois.close();
            fis.close();
            fos.close();
            oos.close();
        }
        catch(IOException ioe){
            ioe.printStackTrace();
        }
        catch (ClassNotFoundException c){
            c.printStackTrace();
        }
    }
    public void edit_course(){
        //search for the course the admin wants to edit
        Scanner input=new Scanner(System.in);
        System.out.println("Enter the id of the course to be edited");
        String id = input.next();
        for (Course c:courses) {
            if (c.getId().equals(id))
                while (true) {
                //print out an options menu for what aspect of the course they would like to edit. then apply appropriate setter
                    System.out.println("What would you like to edit about the course (Enter corresponding number): 1-course name, 2-course id, 3-number of registered students, 4-students in course,5-course instructor,6-maximum number of students,7-course section,8-course location,9-done editing");
                    int user = input.nextInt();
                    String str=input.nextLine();
                    if (user == 1) {
                        System.out.println("Enter the new course name");
                        c.setName(input.next());

                    }
                    if (user == 2) {
                        System.out.println("Enter the new course id");
                        c.setId(input.next());
                    }
                    if (user == 3) {
                        System.out.println("Enter the new number of registered students");
                        c.setRegisteredStudents(input.nextInt());
                    }
                    if (user == 4) {
                        while (true) {
                            System.out.println("Would you like to add or delete students? Enter 1 for add or 2 for delete. 3 if finished.");
                            int user1 = input.nextInt();
                            if (user1 == 1) {
                                System.out.println("Enter new student first name");
                                String first_name = input.next();
                                System.out.println("Enter new student last name");
                                String last_name = input.next();
                                if (c.maxStudents > c.registeredStudents) {
                                    Student new_guy = new Student(first_name, last_name);
                                    c.addStudent(new_guy);
                                } else {
                                    System.out.println("Class is full");
                                }
                            }
                            if (user1 == 2) {
                                System.out.println("Enter removed student first name");
                                String first1_name= input.next();
                                System.out.println("Enter removed student last name");
                                String last1_name=input.next();
                                for (Student s:c.students){
                                    System.out.println(s.firstName+" "+s.lastName);
                                    if (s.firstName.equals(first1_name)&&s.lastName.equals(last1_name)){
                                        c.removeStudent(s);
                                    }
                                }
                            }
                            if (user1 == 3) {
                                break;
                            }
                        }
                    }
                    if (user == 5) {
                        System.out.println("Enter the instructors name");
                        c.setProfessor(input.next());

                    }
                    if (user == 6) {
                        System.out.println("Enter the maximum number of students");
                        c.setMaxStudents(input.nextInt());
                    }
                    if (user == 7) {
                        System.out.println("Enter the course section");
                        c.setSection(input.nextInt());
                    }
                    if (user == 8) {
                        System.out.println("Enter the course location");
                        c.setLocation(input.next());

                    }
                    if (user == 9) {
                        break;
                    }
                }
            }
        }

    public void display_course_info(String id) {
        //prints all course info by id
        for (Course c : courses) {
            if (c.id.equals(id)) {
                c.printCourseInfo();
            }
        }
    }

    //create a view all method
    public void viewAll(){
        //goes through all course object in courses array
        for (Course c:courses){
            c.printCourseInfo();
        }
    }

    public void register_student() {
        //registers a new student by creating a new student object and adding it to the students array in user
        Scanner input=new Scanner(System.in);
        System.out.println("Enter new student first name");
        String first_name = input.next();
        System.out.println("Enter new student last name");
        String last_name = input.next();
        Student dude = new Student(first_name, last_name);
        Allstudents.add(dude);
    }

    public void view_full_courses(){
        //prints information for all full courses
        for (Course c:courses){
            if (c.maxStudents<=c.registeredStudents){
                c.printCourseInfo();
            }
        }
    }

    public void write_full_course_file() {
        //uses the printwriter object to print out all full courses information to a file called full course text
        PrintWriter writer = null;
        try {
           writer=new PrintWriter("Full Courses.txt", "UTF-8");
            for (Course c : courses) {
                if (c.registeredStudents >= c.maxStudents) {
                    writer.write("Course name: " + c.name + "-Course id: " + c.id + "-Number of registered students: " + c.registeredStudents + "-Max students allowed: " + c.maxStudents);
                }
            }
            //catches a potential IOException
        } catch (IOException e) {
            System.out.println("IO Exception");
        }
        finally{
            if (writer!=null){
                writer.close();
            }

        }


    }

    public void view_registered_students(String id){
        //loops through all courses and prints out the first and last name of all student objects registered in the course
        for (Course c: courses){
            if(c.id.equals(id)) {
                for (Student s : c.students) {
                    System.out.print(", " + s.firstName + " " + s.lastName);
                }
            }
        }
    }

    public void view_courses_of_student(Student student){
        //loops through all courses and adds all of the courses to which a student is registered and puts them into an arraylist
        ArrayList<String> course_names_of_Student=new ArrayList<>();
        for (Course c:courses){
            if (c.students.contains(student)){
                course_names_of_Student.add(c.name);
            }
        }
        if (course_names_of_Student.size()==0){
            System.out.println("Not registered anywhere");
        }
        System.out.println(Arrays.toString(course_names_of_Student.toArray()));

    }

    public void sort(){
        //goes through courses array list and orderes them in ascending order via the use of comparator which compares the number of registered students
        Collections.sort(courses, new Comparator<Course>() {
            @Override
            public int compare(Course o1, Course o2) {
                return o1.registeredStudents-o2.registeredStudents;
            }
        });
    }
}
